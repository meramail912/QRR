import qrcode
from io import BytesIO
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.core.files.base import ContentFile
from django.contrib import messages
from django.urls import reverse

from .forms import QRForm, SignUpForm, QREditForm, QRSearchForm
from .models import QRCodeData


@login_required
def home(request):
    qr_img_url = None
    if request.method == "POST":
        form = QRForm(request.POST)
        if form.is_valid():
            business_name = form.cleaned_data.get('business_name')
            name = form.cleaned_data.get('name')
            phone_number = form.cleaned_data.get('phone_number')
            original_url = form.cleaned_data['url']
            fill_color = form.cleaned_data.get('fill_color') or "black"
            back_color = form.cleaned_data.get('back_color') or "white"

            # First save the QRCodeData instance without image
            qr_code = QRCodeData(
                user=request.user,
                business_name=business_name,
                name=name,
                phone_number=phone_number,
                url=original_url
            )
            qr_code.save()

            # Build redirect URL (fixed)
            redirect_url = request.build_absolute_uri(
                reverse('qr_redirect', kwargs={'qr_id': qr_code.id})
            )

            # Generate QR code image with redirect URL encoded
            qr = qrcode.QRCode(box_size=10, border=4)
            qr.add_data(redirect_url)  # fixed redirect URL in QR code
            qr.make(fit=True)
            img = qr.make_image(fill_color=fill_color, back_color=back_color)

            buffer = BytesIO()
            img.save(buffer, format="PNG")
            file_name = f"qr_{request.user.username}_{qr_code.id}.png"

            # Save QR image file
            qr_code.qr_image.save(file_name, ContentFile(buffer.getvalue()))
            qr_code.save()

            qr_img_url = qr_code.qr_image.url
    else:
        form = QRForm()

    return render(request, 'qrgen/home.html', {'form': form, 'qr_img_url': qr_img_url})


@login_required
def history(request):
    qrs = QRCodeData.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'qrgen/history.html', {'qrs': qrs})


@login_required
def edit_qr(request, qr_id):
    qr_code = get_object_or_404(QRCodeData, id=qr_id, user=request.user)
    if request.method == "POST":
        form = QREditForm(request.POST, instance=qr_code)
        if form.is_valid():
            form.save()  # Updates business_name, name, phone_number, url but QR image remains unchanged
            messages.success(request, "QR code details updated (image unchanged).")
            return redirect('history')
    else:
        form = QREditForm(instance=qr_code)
    return render(request, 'qrgen/edit_qr.html', {'form': form, 'qr_code': qr_code})


@login_required
def search_qr(request):
    form = QRSearchForm(request.GET)
    qrs = []
    if form.is_valid():
        query = form.cleaned_data['query']
        if query:
            qrs = QRCodeData.objects.filter(
                user=request.user,
                business_name__icontains=query
            ) | QRCodeData.objects.filter(
                user=request.user,
                name__icontains=query
            ) | QRCodeData.objects.filter(
                user=request.user,
                phone_number__icontains=query
            )
    return render(request, 'qrgen/search.html', {'form': form, 'qrs': qrs})


def signup_view(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = SignUpForm()
    return render(request, 'qrgen/signup.html', {'form': form})


@login_required
def logout_view(request):
    auth_logout(request)
    return redirect('home')


@login_required
def change_url_list(request):
    query = request.GET.get('q', '')
    qrs = QRCodeData.objects.filter(user=request.user)

    if query:
        qrs = qrs.filter(
            business_name__icontains=query
        ) | qrs.filter(name__icontains=query) | qrs.filter(phone_number__icontains=query)

    return render(request, 'qrgen/change_url_list.html', {'qrs': qrs, 'query': query})


@login_required
def update_qr_url(request, qr_id):
    qr_obj = get_object_or_404(QRCodeData, id=qr_id, user=request.user)

    if request.method == "POST":
        new_url = request.POST.get('new_url')
        if new_url:
            qr_obj.url = new_url
            qr_obj.save()  # Keep QR image same, only URL changes
            messages.success(request, "QR URL updated successfully!")
            return redirect('change_url_list')

    return render(request, 'qrgen/update_qr_url.html', {'qr': qr_obj})


# The key redirect view:
def qr_redirect(request, qr_id):
    qr_obj = get_object_or_404(QRCodeData, id=qr_id)
    if qr_obj.url:
        return redirect(qr_obj.url)
    else:
        return render(request, 'qrgen/no_url.html', {'qr': qr_obj})
