from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import QRCodeData

class QRForm(forms.ModelForm):
    class Meta:
        model = QRCodeData
        fields = ['business_name', 'name', 'phone_number', 'url']

class QREditForm(forms.ModelForm):
    class Meta:
        model = QRCodeData
        fields = ['business_name', 'name', 'phone_number', 'url']

class QRSearchForm(forms.Form):
    query = forms.CharField(max_length=255, required=False, label='Search')

class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
