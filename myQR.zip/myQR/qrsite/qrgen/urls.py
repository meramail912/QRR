from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('history/', views.history, name='history'),
    path('search/', views.search_qr, name='search_qr'),
    path('signup/', views.signup_view, name='signup'),
    path('logout/', views.logout_view, name='logout'),
    path('edit/<int:qr_id>/', views.edit_qr, name='edit_qr'),
    path('qr/<int:qr_id>/redirect/', views.qr_redirect, name='qr_redirect'),
    path('qr/<int:qr_id>/redirect/', views.qr_redirect, name='qr_redirect'),

    # Add these for URL change feature:
    path('change-url/', views.change_url_list, name='change_url_list'),
    path('change-url/<int:qr_id>/', views.update_qr_url, name='update_qr_url'),
]
